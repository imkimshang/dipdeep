/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#4F46E5',
          50: '#EEEFFE',
          100: '#E0DFFE',
          200: '#C7C4FC',
          300: '#A7A0FA',
          400: '#8B7FF6',
          500: '#4F46E5',
          600: '#4338CA',
          700: '#3730A3',
          800: '#312E81',
          900: '#1E1B4B',
        }
      }
    },
  },
  plugins: [],
}

