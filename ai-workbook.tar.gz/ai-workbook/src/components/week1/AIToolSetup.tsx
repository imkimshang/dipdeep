import React from 'react';
import { Week1Data } from '../../types/week1';
import { Sparkles, Check } from 'lucide-react';

interface AIToolSetupProps {
  data: Week1Data;
  onUpdate: (updates: Partial<Week1Data>) => void;
}

const popularTools = [
  'ChatGPT',
  'Claude',
  'Gemini',
  'Perplexity',
  'Copilot',
];

export const AIToolSetup: React.FC<AIToolSetupProps> = ({ data, onUpdate }) => {
  return (
    <section className="mb-12">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-500 to-purple-500 p-6">
          <div className="flex items-center space-x-3 text-white">
            <Sparkles className="w-6 h-6" />
            <div>
              <h2 className="text-xl font-bold">나의 AI 파트너 탐색</h2>
              <p className="text-indigo-100 text-sm mt-1">
                12주 동안 함께할 AI 도구를 선택하고 설정해보세요
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Tool Selection */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              사용할 AI 도구 선택
            </label>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
              {popularTools.map((tool) => (
                <button
                  key={tool}
                  onClick={() => onUpdate({ toolName: tool })}
                  className={`px-4 py-3 rounded-lg border-2 transition-all ${
                    data.toolName === tool
                      ? 'border-primary bg-primary text-white'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  <div className="flex items-center justify-center space-x-2">
                    {data.toolName === tool && (
                      <Check className="w-4 h-4" />
                    )}
                    <span className="font-medium">{tool}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Custom Input */}
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">또는 직접 입력:</span>
              <input
                type="text"
                value={
                  popularTools.includes(data.toolName) ? '' : data.toolName
                }
                onChange={(e) => onUpdate({ toolName: e.target.value })}
                placeholder="다른 도구 이름"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
          </div>

          {/* Setup Date */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              계정 생성일
            </label>
            <input
              type="date"
              value={data.setupDate}
              onChange={(e) => onUpdate({ setupDate: e.target.value })}
              className="w-full md:w-64 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>

          {/* First Impression */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              첫인상 및 학습 포부
            </label>
            <textarea
              value={data.impression}
              onChange={(e) => onUpdate({ impression: e.target.value })}
              placeholder="AI를 처음 사용해본 느낌은 어떤가요? 이 도구로 무엇을 배우고 싶나요?"
              rows={6}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
            />
            <div className="mt-2 flex justify-between items-center">
              <span className="text-sm text-gray-500">
                💡 팁: 구체적으로 작성할수록 학습 방향을 잡는 데 도움이 됩니다
              </span>
              <span className="text-sm text-gray-400">
                {data.impression.length} / 500자
              </span>
            </div>
          </div>

          {/* Setup Status */}
          {data.toolName && data.setupDate && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center space-x-2 text-green-800">
                <Check className="w-5 h-5" />
                <span className="font-medium">
                  {data.toolName} 설정 완료!
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
