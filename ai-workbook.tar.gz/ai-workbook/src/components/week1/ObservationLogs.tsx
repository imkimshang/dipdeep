import React, { useState } from 'react';
import { Week1Data, ObservationLog } from '../../types/week1';
import { Camera, Plus, Trash2, Upload, Loader2 } from 'lucide-react';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage, auth } from '../../firebase/config';

interface ObservationLogsProps {
  data: Week1Data;
  onUpdate: (updates: Partial<Week1Data>) => void;
}

export const ObservationLogs: React.FC<ObservationLogsProps> = ({
  data,
  onUpdate,
}) => {
  const [uploadingIndex, setUploadingIndex] = useState<number | null>(null);

  const updateLog = (index: number, updates: Partial<ObservationLog>) => {
    const newLogs = [...data.observationLogs];
    newLogs[index] = { ...newLogs[index], ...updates };
    onUpdate({ observationLogs: newLogs });
  };

  const addLog = () => {
    const newId =
      Math.max(...data.observationLogs.map((log) => log.id), 0) + 1;
    const newLog: ObservationLog = {
      id: newId,
      title: '',
      description: '',
      imageUrl: '',
    };
    onUpdate({ observationLogs: [...data.observationLogs, newLog] });
  };

  const deleteLog = (index: number) => {
    if (data.observationLogs.length <= 1) {
      alert('최소 1개의 관찰 로그는 유지해야 합니다.');
      return;
    }
    const newLogs = data.observationLogs.filter((_, i) => i !== index);
    onUpdate({ observationLogs: newLogs });
  };

  const handleImageUpload = async (
    index: number,
    file: File
  ) => {
    if (!auth.currentUser?.email) {
      alert('로그인이 필요합니다.');
      return;
    }

    setUploadingIndex(index);

    try {
      // Firebase Storage에 업로드
      const timestamp = Date.now();
      const fileName = `${auth.currentUser.email}/week1/observation_${timestamp}_${file.name}`;
      const storageRef = ref(storage, fileName);

      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);

      updateLog(index, { imageUrl: downloadURL });
    } catch (error) {
      console.error('이미지 업로드 실패:', error);
      alert('이미지 업로드에 실패했습니다.');
    } finally {
      setUploadingIndex(null);
    }
  };

  return (
    <section className="mb-12">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="bg-gradient-to-r from-pink-500 to-rose-500 p-6">
          <div className="flex items-center space-x-3 text-white">
            <Camera className="w-6 h-6" />
            <div>
              <h2 className="text-xl font-bold">일상 불편함 관찰 로그</h2>
              <p className="text-pink-100 text-sm mt-1">
                주변의 불편한 점들을 사진과 함께 기록해보세요
              </p>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="space-y-6">
            {data.observationLogs.map((log, index) => (
              <div
                key={log.id}
                className="border-2 border-gray-200 rounded-xl overflow-hidden hover:border-primary transition-colors"
              >
                {/* Image Section */}
                <div className="bg-gray-50 aspect-video relative">
                  {log.imageUrl ? (
                    <img
                      src={log.imageUrl}
                      alt={log.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Camera className="w-16 h-16 text-gray-300" />
                    </div>
                  )}

                  {/* Upload Button */}
                  <label
                    className={`absolute bottom-4 right-4 px-4 py-2 rounded-lg cursor-pointer transition-all ${
                      uploadingIndex === index
                        ? 'bg-gray-400 cursor-not-allowed'
                        : 'bg-white hover:bg-gray-100 shadow-lg'
                    }`}
                  >
                    {uploadingIndex === index ? (
                      <div className="flex items-center space-x-2 text-gray-600">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">업로드 중...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2 text-gray-700">
                        <Upload className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          {log.imageUrl ? '이미지 교체' : '이미지 업로드'}
                        </span>
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleImageUpload(index, file);
                      }}
                      disabled={uploadingIndex === index}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Content Section */}
                <div className="p-6 space-y-4">
                  <div className="flex items-start justify-between">
                    <span className="inline-flex items-center px-3 py-1 bg-pink-100 text-pink-700 rounded-full text-sm font-medium">
                      관찰 #{index + 1}
                    </span>
                    {data.observationLogs.length > 1 && (
                      <button
                        onClick={() => deleteLog(index)}
                        className="text-red-500 hover:text-red-700 transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      불편함 제목
                    </label>
                    <input
                      type="text"
                      value={log.title}
                      onChange={(e) => updateLog(index, { title: e.target.value })}
                      placeholder="예: 카페에서 노트북 충전이 불편해요"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      상세 설명
                    </label>
                    <textarea
                      value={log.description}
                      onChange={(e) =>
                        updateLog(index, { description: e.target.value })
                      }
                      placeholder="어떤 상황에서 무엇이 불편했나요? 구체적으로 작성해주세요."
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                    />
                  </div>
                </div>
              </div>
            ))}

            {/* Add Button */}
            <button
              onClick={addLog}
              className="w-full py-4 border-2 border-dashed border-gray-300 rounded-xl hover:border-primary hover:bg-primary/5 transition-colors text-gray-600 hover:text-primary"
            >
              <div className="flex items-center justify-center space-x-2">
                <Plus className="w-5 h-5" />
                <span className="font-medium">새 관찰 로그 추가</span>
              </div>
            </button>
          </div>

          {/* Tips */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-semibold text-blue-900 text-sm mb-2">
              📸 관찰 팁
            </h4>
            <ul className="space-y-1 text-sm text-blue-800">
              <li>• 일상에서 마주치는 사소한 불편함도 좋은 기획의 씨앗입니다</li>
              <li>• 사진은 문제 상황을 가장 잘 보여주는 장면으로 촬영하세요</li>
              <li>• "왜 불편한가?"보다 "어떻게 개선할 수 있을까?"를 생각해보세요</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
