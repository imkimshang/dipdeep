import React, { useState, useEffect } from 'react';
import { Week1Data } from '../../types/week1';
import { Code2, Copy, Check } from 'lucide-react';

interface PromptBuilderProps {
  data: Week1Data;
  onUpdate: (updates: Partial<Week1Data>) => void;
}

export const PromptBuilder: React.FC<PromptBuilderProps> = ({
  data,
  onUpdate,
}) => {
  const [copied, setCopied] = useState(false);
  const [generatedPrompt, setGeneratedPrompt] = useState('');

  // Generate prompt in real-time
  useEffect(() => {
    const parts = [];
    if (data.role) parts.push(`[Role] ${data.role}`);
    if (data.context) parts.push(`[Context] ${data.context}`);
    if (data.task) parts.push(`[Task] ${data.task}`);

    setGeneratedPrompt(parts.join('\n\n'));
  }, [data.role, data.context, data.task]);

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="mb-12">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="bg-gradient-to-r from-slate-700 to-slate-900 p-6">
          <div className="flex items-center space-x-3 text-white">
            <Code2 className="w-6 h-6" />
            <div>
              <h2 className="text-xl font-bold">R-C-T 프롬프트 연습장</h2>
              <p className="text-slate-300 text-sm mt-1">
                효율적인 질문 구조를 익혀보세요
              </p>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Input Section */}
            <div className="space-y-6">
              <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                <h3 className="font-semibold text-indigo-900 mb-2">
                  R-C-T 프레임워크란?
                </h3>
                <ul className="space-y-2 text-sm text-indigo-800">
                  <li>
                    <strong>R (Role):</strong> AI에게 부여할 역할
                  </li>
                  <li>
                    <strong>C (Context):</strong> 질문의 배경과 상황
                  </li>
                  <li>
                    <strong>T (Task):</strong> 구체적인 요청사항
                  </li>
                </ul>
              </div>

              {/* Role Input */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary text-white text-xs mr-2">
                    R
                  </span>
                  Role (역할)
                </label>
                <input
                  type="text"
                  value={data.role}
                  onChange={(e) => onUpdate({ role: e.target.value })}
                  placeholder="예: 너는 경험이 풍부한 UX 디자이너야"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>

              {/* Context Input */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-purple-500 text-white text-xs mr-2">
                    C
                  </span>
                  Context (맥락)
                </label>
                <textarea
                  value={data.context}
                  onChange={(e) => onUpdate({ context: e.target.value })}
                  placeholder="예: 고등학생들을 위한 시간 관리 앱을 기획하고 있어. 주요 문제는 학생들이 공부 계획을 세워도 실천하지 못한다는 거야."
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                />
              </div>

              {/* Task Input */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-pink-500 text-white text-xs mr-2">
                    T
                  </span>
                  Task (과업)
                </label>
                <input
                  type="text"
                  value={data.task}
                  onChange={(e) => onUpdate({ task: e.target.value })}
                  placeholder="예: 이 문제를 해결할 수 있는 핵심 기능 3가지를 제안해줘"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>
            </div>

            {/* Live Preview Section */}
            <div>
              <div className="sticky top-24">
                <div className="bg-slate-900 rounded-lg overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 bg-slate-800 border-b border-slate-700">
                    <span className="text-slate-300 text-sm font-medium">
                      생성된 프롬프트
                    </span>
                    <button
                      onClick={handleCopy}
                      disabled={!generatedPrompt}
                      className="flex items-center space-x-2 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span className="text-sm">복사됨!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span className="text-sm">복사</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="p-4">
                    {generatedPrompt ? (
                      <pre className="text-sm text-slate-200 whitespace-pre-wrap font-mono leading-relaxed">
                        {generatedPrompt}
                      </pre>
                    ) : (
                      <p className="text-slate-500 text-sm italic">
                        위 입력 필드를 채우면 여기에 프롬프트가 실시간으로
                        나타납니다.
                      </p>
                    )}
                  </div>
                </div>

                {/* Tips */}
                <div className="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <h4 className="font-semibold text-amber-900 text-sm mb-2">
                    💡 프롬프트 작성 팁
                  </h4>
                  <ul className="space-y-1 text-sm text-amber-800">
                    <li>• 구체적일수록 좋은 답변을 받을 수 있어요</li>
                    <li>• 맥락(Context)을 충분히 제공하세요</li>
                    <li>• 요청사항은 명확하게 작성하세요</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
