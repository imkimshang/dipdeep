import React, { useState, useEffect } from 'react';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { db, auth } from '../firebase/config';
import { Week1Data, initialWeek1Data } from '../types/week1';
import { Save, CheckCircle } from 'lucide-react';
import { AIToolSetup } from './week1/AIToolSetup';
import { PromptBuilder } from './week1/PromptBuilder';
import { ObservationLogs } from './week1/ObservationLogs';

export const Week1Workbook: React.FC = () => {
  const [data, setData] = useState<Week1Data>(initialWeek1Data);
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  const userEmail = auth.currentUser?.email;

  // 데이터 로드
  useEffect(() => {
    const loadData = async () => {
      if (!userEmail) return;

      try {
        const docRef = doc(db, 'workbooks', userEmail, 'weeks', 'week1');
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const loadedData = docSnap.data() as Week1Data;
          setData({
            ...loadedData,
            updatedAt: loadedData.updatedAt || new Date(),
          });
          setLastSaved(loadedData.updatedAt || new Date());
        }
      } catch (error) {
        console.error('데이터 로드 실패:', error);
      }
    };

    loadData();
  }, [userEmail]);

  // 자동 저장 (3초 디바운스)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (userEmail) {
        saveData();
      }
    }, 3000);

    return () => clearTimeout(timer);
  }, [data]);

  const saveData = async () => {
    if (!userEmail) return;

    setSaving(true);
    try {
      const docRef = doc(db, 'workbooks', userEmail, 'weeks', 'week1');
      const dataToSave = {
        ...data,
        updatedAt: new Date(),
      };

      await setDoc(docRef, dataToSave);
      setLastSaved(new Date());
    } catch (error) {
      console.error('저장 실패:', error);
    } finally {
      setSaving(false);
    }
  };

  const updateData = (updates: Partial<Week1Data>) => {
    setData((prev) => ({ ...prev, ...updates }));
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center space-x-2 text-sm text-gray-500 mb-2">
              <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full font-medium">
                Phase 1: Data
              </span>
              <span>•</span>
              <span>Week 1</span>
            </div>
            <h1 className="text-3xl font-bold text-gray-900">
              AI 기획 입문 및 문제 발견
            </h1>
            <p className="text-gray-600 mt-2">
              Discovery & AI Partnership
            </p>
          </div>
          <div className="text-right">
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              {saving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary" />
                  <span>저장 중...</span>
                </>
              ) : lastSaved ? (
                <>
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>
                    {lastSaved.toLocaleTimeString('ko-KR', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}{' '}
                    저장됨
                  </span>
                </>
              ) : null}
            </div>
          </div>
        </div>

        {/* 학습 목표 */}
        <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-indigo-900 mb-3">
            이번 주 학습 목표
          </h2>
          <ul className="space-y-2 text-indigo-800">
            <li className="flex items-start space-x-2">
              <span className="text-indigo-500 mt-1">•</span>
              <span>
                AI 도구를 설정하고 기획 파트너로 인식하기
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-indigo-500 mt-1">•</span>
              <span>
                효율적인 질문 기법(R-C-T) 익히기
              </span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-indigo-500 mt-1">•</span>
              <span>
                주변의 불편함을 관찰하고 기록하기
              </span>
            </li>
          </ul>
        </div>
      </div>

      {/* Section 1: AI Tool Setup */}
      <AIToolSetup
        data={data}
        onUpdate={updateData}
      />

      {/* Section 2: Prompt Builder */}
      <PromptBuilder
        data={data}
        onUpdate={updateData}
      />

      {/* Section 3: Observation Logs */}
      <ObservationLogs
        data={data}
        onUpdate={updateData}
      />

      {/* Manual Save Button */}
      <div className="mt-8 flex justify-end">
        <button
          onClick={saveData}
          disabled={saving}
          className="flex items-center space-x-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Save className="w-5 h-5" />
          <span>{saving ? '저장 중...' : '수동 저장'}</span>
        </button>
      </div>
    </div>
  );
};
