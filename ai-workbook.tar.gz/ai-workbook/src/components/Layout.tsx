import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BookOpen, CheckCircle2, Circle, LogOut } from 'lucide-react';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase/config';

interface LayoutProps {
  children: React.ReactNode;
}

const weeks = [
  { num: 1, title: 'AI 기획 입문 및 문제 발견', phase: 'Data' },
  { num: 2, title: '사용자 인터뷰 설계', phase: 'Data' },
  { num: 3, title: '공공데이터 탐색', phase: 'Data' },
  { num: 4, title: '데이터 정제 및 시각화', phase: 'Data' },
  { num: 5, title: '인사이트 도출', phase: 'Insight' },
  { num: 6, title: '페르소나 설계', phase: 'Insight' },
  { num: 7, title: 'User Journey Map', phase: 'Insight' },
  { num: 8, title: '아이디어 발산과 수렴', phase: 'Insight' },
  { num: 9, title: 'IA 설계 및 와이어프레임', phase: 'Prototype' },
  { num: 10, title: 'UI 디자인', phase: 'Prototype' },
  { num: 11, title: '노코드 프로토타입 제작', phase: 'Prototype' },
  { num: 12, title: '최종 발표 및 포트폴리오', phase: 'Prototype' },
];

const phaseColors: Record<string, string> = {
  Data: 'bg-indigo-500',
  Insight: 'bg-purple-500',
  Prototype: 'bg-pink-500',
};

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const currentWeek = parseInt(location.pathname.split('/week/')[1]) || 1;

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('로그아웃 실패:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <BookOpen className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  AI 서비스 기획 워크북
                </h1>
                <p className="text-sm text-gray-500">12주 완성 프로그램</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <span className="text-sm text-gray-600">
                {auth.currentUser?.email}
              </span>
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-600">
                  Week {currentWeek} / 12
                </span>
                <div className="w-32 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all"
                    style={{ width: `${(currentWeek / 12) * 100}%` }}
                  />
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm">로그아웃</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar Navigation */}
        <aside className="w-80 bg-white border-r border-gray-200 min-h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto">
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              학습 로드맵
            </h2>
            <div className="space-y-1">
              {weeks.map((week) => {
                const isActive = currentWeek === week.num;
                const isCompleted = currentWeek > week.num;

                return (
                  <Link
                    key={week.num}
                    to={`/week/${week.num}`}
                    className={`block px-4 py-3 rounded-lg transition-colors ${
                      isActive
                        ? 'bg-primary text-white'
                        : isCompleted
                        ? 'bg-gray-50 hover:bg-gray-100 text-gray-700'
                        : 'text-gray-400 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-0.5">
                        {isCompleted ? (
                          <CheckCircle2 className="w-5 h-5" />
                        ) : (
                          <Circle className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-semibold">
                            Week {week.num}
                          </span>
                          <span
                            className={`text-xs px-2 py-0.5 rounded-full ${
                              isActive
                                ? 'bg-white/20 text-white'
                                : 'bg-gray-100 text-gray-600'
                            }`}
                          >
                            {week.phase}
                          </span>
                        </div>
                        <p
                          className={`text-sm mt-1 ${
                            isActive ? 'font-medium' : ''
                          }`}
                        >
                          {week.title}
                        </p>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>

            {/* Phase Legend */}
            <div className="mt-8 pt-6 border-t border-gray-200">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                학습 단계
              </h3>
              <div className="space-y-2">
                {Object.entries(phaseColors).map(([phase, color]) => (
                  <div key={phase} className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${color}`} />
                    <span className="text-sm text-gray-600">{phase}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">{children}</main>
      </div>
    </div>
  );
};
