import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './firebase/config';
import { Layout } from './components/Layout';
import { Week1Workbook } from './components/Week1Workbook';
import { AuthPage } from './components/AuthPage';

function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  if (!user) {
    return <AuthPage onAuth={() => setUser(auth.currentUser)} />;
  }

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Navigate to="/week/1" replace />} />
          <Route path="/week/1" element={<Week1Workbook />} />
          {/* 추후 다른 주차 추가 */}
          <Route path="/week/:weekNum" element={<ComingSoon />} />
        </Routes>
      </Layout>
    </Router>
  );
}

// Coming Soon 페이지 (임시)
const ComingSoon: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto text-center py-20">
      <h1 className="text-4xl font-bold text-gray-900 mb-4">준비 중입니다</h1>
      <p className="text-gray-600">
        이 주차의 워크북은 곧 공개될 예정입니다.
      </p>
    </div>
  );
};

export default App;
