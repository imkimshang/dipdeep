export interface ObservationLog {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
}

export interface Week1Data {
  toolName: string;
  setupDate: string;
  impression: string;
  role: string;
  context: string;
  task: string;
  observationLogs: ObservationLog[];
  updatedAt: Date;
}

export const initialWeek1Data: Week1Data = {
  toolName: '',
  setupDate: '',
  impression: '',
  role: '',
  context: '',
  task: '',
  observationLogs: [
    { id: 1, title: '', description: '', imageUrl: '' },
    { id: 2, title: '', description: '', imageUrl: '' },
    { id: 3, title: '', description: '', imageUrl: '' },
  ],
  updatedAt: new Date(),
};
