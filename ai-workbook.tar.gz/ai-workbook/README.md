# AI 서비스 기획 워크북 - 12주 완성 프로그램

React + TypeScript + Firebase 기반 인터랙티브 학습 워크북

## 📋 프로젝트 개요

12주 동안 AI를 활용한 서비스 기획을 학습하는 인터랙티브 워크북 플랫폼입니다.

### 주요 기능

- ✅ 12주 커리큘럼 구조 (Phase 1: Data → Phase 2: Insight → Phase 3: Prototype)
- ✅ Week 1: AI 기획 입문 및 문제 발견
  - AI 도구 설정
  - R-C-T 프롬프트 빌더
  - 일상 불편함 관찰 로그 (이미지 업로드 지원)
- ✅ 실시간 자동 저장 (Firestore)
- ✅ 이메일 기반 학생 구분
- ✅ 반응형 디자인

## 🚀 설치 및 실행

### 1. 패키지 설치

```bash
cd ai-workbook
npm install
```

### 2. Firebase 설정

`src/firebase/config.ts` 파일에서 Firebase 프로젝트 설정을 입력하세요:

```typescript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

### 3. Firebase 프로젝트 설정

Firebase Console에서 다음을 활성화하세요:

1. **Authentication** → Email/Password 로그인 활성화
2. **Firestore Database** → 데이터베이스 생성
3. **Storage** → 이미지 저장소 생성

### 4. Firestore 보안 규칙

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /workbooks/{userEmail}/weeks/{weekId} {
      allow read, write: if request.auth != null && request.auth.token.email == userEmail;
    }
  }
}
```

### 5. Storage 보안 규칙

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{userEmail}/{allPaths=**} {
      allow read, write: if request.auth != null && request.auth.token.email == userEmail;
    }
  }
}
```

### 6. 개발 서버 실행

```bash
npm start
```

브라우저에서 `http://localhost:3000` 접속

## 📁 프로젝트 구조

```
ai-workbook/
├── src/
│   ├── components/
│   │   ├── Layout.tsx                 # 전체 레이아웃 (12주 네비게이션)
│   │   ├── Week1Workbook.tsx          # Week 1 메인 컴포넌트
│   │   └── week1/
│   │       ├── AIToolSetup.tsx        # Section 1: AI 도구 설정
│   │       ├── PromptBuilder.tsx      # Section 2: R-C-T 프롬프트 빌더
│   │       └── ObservationLogs.tsx    # Section 3: 관찰 로그
│   ├── firebase/
│   │   └── config.ts                  # Firebase 설정
│   ├── types/
│   │   └── week1.ts                   # Week 1 데이터 타입
│   ├── App.tsx                        # 라우터 설정
│   └── index.tsx                      # 앱 진입점
├── package.json
└── tailwind.config.js
```

## 🎨 디자인 시스템

### 컬러 팔레트

- **Primary (Indigo)**: `#4F46E5` - 메인 액션 및 강조
- **Phase Colors**:
  - Data (Indigo): `#4F46E5`
  - Insight (Purple): `#9333EA`
  - Prototype (Pink): `#EC4899`

### 주요 컴포넌트

- **카드 섹션**: 각 기능별 독립적인 카드 레이아웃
- **IDE 스타일 프롬프트 빌더**: 다크 모드 배경 (`bg-slate-900`)
- **인스타그램 스타일 관찰 로그**: 이미지 중심 레이아웃

## 💾 데이터 구조

### Firestore 경로

```
workbooks/
  └── {userEmail}/
      └── weeks/
          └── week1/
              ├── toolName: string
              ├── setupDate: string
              ├── impression: string
              ├── role: string
              ├── context: string
              ├── task: string
              ├── observationLogs: array
              └── updatedAt: timestamp
```

### Storage 경로

```
{userEmail}/
  └── week1/
      └── observation_{timestamp}_{filename}
```

## 🔧 주요 기능 설명

### 1. 자동 저장

- 3초 디바운스 적용
- 실시간 저장 상태 표시
- 수동 저장 버튼 제공

### 2. 실시간 프롬프트 생성

- R-C-T 입력 시 즉시 프롬프트 조합
- 클립보드 복사 기능
- 라이브 프리뷰

### 3. 이미지 업로드

- Firebase Storage 연동
- 업로드 진행 상태 표시
- 이미지 교체 기능

## 📝 추가 개발 계획

- [ ] Week 2-12 워크북 추가
- [ ] CMS 관리자 페이지
- [ ] 학생 진행도 통계 대시보드
- [ ] PDF 내보내기 기능
- [ ] 팀 협업 기능

## 🛠️ 기술 스택

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Database**: Firebase Firestore
- **Storage**: Firebase Storage
- **Authentication**: Firebase Auth
- **Routing**: React Router v6
- **Icons**: Lucide React

## 📄 라이선스

MIT License

## 👤 개발자

수 (AI Culture Lab)
